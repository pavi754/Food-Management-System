import React from "react";
import { Link } from "react-router-dom";
import { FaUserCog, FaUsers, FaUser, FaUtensils } from "react-icons/fa"; // Import icons
import "./Sidebar.css";

const Sidebar = () => {
  return (
    <div className="sidebar">
      <h2>Dashboard</h2>
      <ul>
        <li>
          <Link to="/admin">
            <FaUserCog className="icon" /> Admin Panel
          </Link>
        </li>
        <li>
          <Link to="/employee">
            <FaUsers className="icon" /> Employee
          </Link>
        </li>
        <li>
          <Link to="/user">
            <FaUser className="icon" /> User
          </Link>
        </li>
        <li>
          <Link to="/menu">
            <FaUtensils className="icon" /> Menu
          </Link>
        </li>
      </ul>
    </div>
  );
};

export default Sidebar;
