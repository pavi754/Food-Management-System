import React, { useState } from "react";
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Button, Dialog, DialogActions, DialogContent, DialogTitle, TextField, IconButton } from "@mui/material";
import { Edit, Delete } from "@mui/icons-material";


const AdminPage = () => {
  const [menuItems, setMenuItems] = useState([
    { id: 1, name: "Pizza", price: 250, image: "https://via.placeholder.com/100" },
    { id: 2, name: "Burger", price: 150, image: "https://via.placeholder.com/100" },
    { id: 3, name: "Biryani", price: 350, image: "https://via.placeholder.com/100" },
  ]);

  const [open, setOpen] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [currentItem, setCurrentItem] = useState({ id: null, name: "", price: "", image: "" });

  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deleteItemId, setDeleteItemId] = useState(null);

  // Open Add/Edit Modal
  const handleOpen = (item = { id: null, name: "", price: "", image: "" }) => {
    setCurrentItem(item);
    setEditMode(!!item.id);
    setOpen(true);
  };

  // Close Modal
  const handleClose = () => {
    setOpen(false);
    setCurrentItem({ id: null, name: "", price: "", image: "" });
  };

  // Handle Input Change
  const handleChange = (e) => {
    setCurrentItem({ ...currentItem, [e.target.name]: e.target.value });
  };

  // Save Item (Add or Edit)
  const handleSave = () => {
    if (!currentItem.name || !currentItem.price || !currentItem.image) {
      alert("All fields are required!");
      return;
    }

    const newItem = { 
      ...currentItem, 
      id: editMode ? currentItem.id : menuItems.length + 1, 
      price: Number(currentItem.price) 
    };

    if (editMode) {
      setMenuItems(menuItems.map((item) => (item.id === currentItem.id ? newItem : item)));
    } else {
      setMenuItems([...menuItems, newItem]);
    }

    handleClose();
  };

  // Open Delete Confirmation Dialog
  const handleDeleteConfirm = (id) => {
    setDeleteItemId(id);
    setDeleteDialogOpen(true);
  };

  // Delete Item
  const handleDelete = () => {
    setMenuItems(menuItems.filter((item) => item.id !== deleteItemId));
    setDeleteDialogOpen(false);
  };

  return (
    <div>
      <h2 style={{ textAlign: "center" }}>Admin Panel - Manage Menu</h2>
      <Button variant="contained" color="primary" onClick={() => handleOpen()} style={{ marginBottom: "10px" }}>
        Add Food Item
      </Button>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Image</TableCell>
              <TableCell>Name</TableCell>
              <TableCell>Price</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {menuItems.map((item) => (
              <TableRow key={item.id}>
                <TableCell>
                  <img src={item.image} alt={item.name} width="50" />
                </TableCell>
                <TableCell>{item.name}</TableCell>
                <TableCell>₹{item.price}</TableCell>
                <TableCell>
                  <IconButton color="primary" onClick={() => handleOpen(item)}>
                    <Edit />
                  </IconButton>
                  <IconButton color="secondary" onClick={() => handleDeleteConfirm(item.id)}>
                    <Delete />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Add/Edit Dialog */}
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>{editMode ? "Edit Food Item" : "Add Food Item"}</DialogTitle>
        <DialogContent>
          <TextField label="Name" name="name" value={currentItem.name} onChange={handleChange} fullWidth margin="dense" />
          <TextField label="Price" name="price" type="number" value={currentItem.price} onChange={handleChange} fullWidth margin="dense" />
          <TextField label="Image URL" name="image" value={currentItem.image} onChange={handleChange} fullWidth margin="dense" />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="secondary">Cancel</Button>
          <Button onClick={handleSave} color="primary">{editMode ? "Update" : "Add"}</Button>
        </DialogActions>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onClose={() => setDeleteDialogOpen(false)}>
        <DialogTitle>Confirm Delete</DialogTitle>
        <DialogContent>Are you sure you want to delete this item?</DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteDialogOpen(false)} color="primary">Cancel</Button>
          <Button onClick={handleDelete} color="secondary">Delete</Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default AdminPage;