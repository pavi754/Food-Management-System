import React, { useEffect, useState } from "react";
import {
  Container,
  Grid,
  Card,
  CardMedia,
  CardContent,
  Typography,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  TextField,
  IconButton,
} from "@mui/material";
import { Edit, Delete } from "@mui/icons-material";

const Menu = () => {
  const [foodItems, setFoodItems] = useState([]);
  const [editItem, setEditItem] = useState(null);
  const [open, setOpen] = useState(false);
  const [formData, setFormData] = useState({ name: "", description: "", price: "", image: "" });

  // Fetch food items from API
  useEffect(() => {
    fetch("https://www.themealdb.com/api/json/v1/1/filter.php?c=Chicken")
      .then((response) => response.json())
      .then((data) => {
        if (data.meals) {
          const formattedData = data.meals.map((item) => ({
            id: item.idMeal,
            name: item.strMeal,
            image: item.strMealThumb,
            category: "Chicken",
            description: `Delicious ${item.strMeal} with rich flavors.`,
            price: Math.floor(Math.random() * 200) + 100, // Random price between ₹100-₹300
          }));
          setFoodItems(formattedData);
        }
      })
      .catch((error) => console.error("Error fetching food data:", error));
  }, []);

  // Handle delete food item
  const handleDelete = (id) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this item?");
    if (confirmDelete) {
      setFoodItems(foodItems.filter((item) => item.id !== id));
    }
  };

  // Handle edit food item
  const handleEdit = (item) => {
    setEditItem(item);
    setFormData({ name: item.name, description: item.description, price: item.price, image: item.image });
    setOpen(true);
  };

  // Handle image upload
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData((prev) => ({ ...prev, image: reader.result }));
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle update food item
  const handleUpdate = () => {
    setFoodItems(
      foodItems.map((item) =>
        item.id === editItem.id
          ? { ...item, name: formData.name, description: formData.description, price: formData.price, image: formData.image }
          : item
      )
    );
    setOpen(false);
    setEditItem(null);
  };

  return (
    <Container sx={{ mt: 4 }}>
      <Typography variant="h4" textAlign="center" mb={4}>
        Menu
      </Typography>

      {/* Food Items */}
      <Grid container spacing={3}>
        {foodItems.map((food) => (
          <Grid item xs={12} sm={6} md={4} key={food.id}>
            <Card>
              <CardMedia component="img" height="200" image={food.image} alt={food.name} />
              <CardContent>
                <Typography variant="h6">{food.name}</Typography>
                <Typography variant="body2" color="textSecondary">
                  {food.description}
                </Typography>
                <Typography variant="h6" color="primary">
                  ₹{food.price}
                </Typography>
                <IconButton onClick={() => handleEdit(food)} color="primary">
                  <Edit />
                </IconButton>
                <IconButton onClick={() => handleDelete(food.id)} color="error">
                  <Delete />
                </IconButton>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Edit Food Dialog */}
      <Dialog open={open} onClose={() => setOpen(false)}>
        <DialogTitle>Edit Food Item</DialogTitle>
        <DialogContent>
          <TextField
            label="Name"
            fullWidth
            margin="dense"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          />
          <TextField
            label="Description"
            fullWidth
            margin="dense"
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          />
          <TextField
            label="Price"
            fullWidth
            margin="dense"
            type="number"
            value={formData.price}
            onChange={(e) => setFormData({ ...formData, price: e.target.value })}
          />
          <input type="file" accept="image/*" onChange={handleImageChange} />
          {formData.image && (
            <img src={formData.image} alt="Preview" style={{ width: "100%", marginTop: "10px" }} />
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Cancel</Button>
          <Button onClick={handleUpdate} color="primary">
            Update
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default Menu;
