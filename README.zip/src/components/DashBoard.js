import React from "react";
import { Routes, Route, Link } from "react-router-dom";
import { Drawer, List, ListItem, ListItemText, Toolbar, CssBaseline } from "@mui/material";
import AdminPage from "./AdminPage";
import Menu from "./Menu";

const Dashboard = () => {
  return (
    <div style={{ display: "flex" }}>
      <CssBaseline />
      {/* Sidebar */}
      <Drawer variant="permanent" sx={{ width: 240, flexShrink: 0 }}>
        <Toolbar />
        <List>
          <ListItem button component={Link} to="/admin">
            <ListItemText primary="Admin Panel" />
          </ListItem>
          <ListItem button component={Link} to="/menu">
            <ListItemText primary="Food Menu" />
          </ListItem>
        </List>
      </Drawer>

      {/* Main Content */}
      <div style={{ flexGrow: 1, padding: "20px" }}>
        <h1 style={{ textAlign: "center" }}>Food Zone</h1>
        <Routes>
          <Route path="/admin" element={<AdminPage />} />
          <Route path="/menu" element={<Menu />} />
        </Routes>
      </div>
    </div>
  );
};

export default Dashboard;
